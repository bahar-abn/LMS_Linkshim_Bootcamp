<?php
use app\core\Application;

class m0003_create_courses_table
{
    public function up()
    {
        $db = Application::$app->db;
        $SQL = "CREATE TABLE courses (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            instructor_id INT NOT NULL,
            category_id INT NOT NULL,
            image_path VARCHAR(255),
            price DECIMAL(10,2) DEFAULT 0,
            status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (instructor_id) REFERENCES users(id),
            FOREIGN KEY (category_id) REFERENCES categories(id)
        ) ENGINE=INNODB;";
        $db->pdo->exec($SQL);
    }

    public function down()
    {
        $db = Application::$app->db;
        $SQL = "DROP TABLE courses;";
        $db->pdo->exec($SQL);
    }
}